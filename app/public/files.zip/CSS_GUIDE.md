# 📘 Guida CSS Bricoccole - Versione 2.0

## 🎯 Principi del Refactoring

### Cosa è stato migliorato:

1. **Variabili CSS** - Tutte le costanti (colori, spacing, font-size) sono centralizzate
2. **Mobile-First** - Design ottimizzato per dispositivi mobili prima
3. **Naming Consistente** - Nomi delle classi chiari e descrittivi
4. **Modulare** - Facile aggiungere o rimuovere sezioni
5. **Accessibile** - Include supporto per screen reader e keyboard navigation
6. **Performance** - Ridotto codice ridondante, migliori transizioni

---

## 🎨 Sistema di Variabili CSS

### Colori
```css
--color-primary: #f6c7c3;          /* Rosa principale */
--color-primary-dark: #d9b6b3;     /* Rosa scuro */
--color-text: #574240;             /* Testo principale */
--color-text-accent: #64070d;      /* Testo rosso scuro */
```

### Spacing (multipli di 4px)
```css
--space-xs: 0.25rem;   /* 4px  - Mini */
--space-sm: 0.5rem;    /* 8px  - Piccolo */
--space-md: 1rem;      /* 16px - Medio */
--space-lg: 1.5rem;    /* 24px - Grande */
--space-xl: 2rem;      /* 32px - Extra Large */
```

### Font Sizes
```css
--font-sm: 1rem;       /* Piccolo */
--font-md: 1.1rem;     /* Medio */
--font-lg: 1.2rem;     /* Grande */
--font-xl: 1.4rem;     /* Extra Large */
--font-5xl: 5rem;      /* Titoli grandi */
```

---

## 📱 Breakpoints Responsive

```css
/* Desktop: > 1000px (default) */
/* Tablet:  ≤ 1000px */
/* Mobile:  ≤ 500px */
```

### Comportamento per dispositivo:

**Desktop (> 1000px)**
- Nav cards: 8 colonne
- Main content: 2 colonne (content + sidebar)
- Container: 80% larghezza

**Tablet (≤ 1000px)**
- Nav cards: 2 colonne
- Main content: 1 colonna (stack verticale)
- Container: 90% larghezza

**Mobile (≤ 500px)**
- Nav cards: 1 colonna
- Font sizes ridotti automaticamente
- Container: 95% larghezza
- Padding ridotti per massimizzare spazio

---

## 🧩 Struttura delle Classi

### Layout Principal
```html
<div class="main-container">
  <!-- Tutto il contenuto qui -->
</div>
```

### Header
```html
<header class="header-section">
  <h1 class="site-title">Bricoccole</h1>
  <p class="site-subtitle">Sottotitolo</p>
</header>
```

### Navigation Cards
```html
<nav class="nav-cards-container">
  <a href="/path" class="nav-card">
    <h3 class="nav-card-title">🏠HOME</h3>
    <p class="nav-card-description">Descrizione</p>
  </a>
</nav>
```

### Main Content Area
```html
<main class="main-content-area">
  <section class="content-section">
    <!-- Contenuto principale -->
  </section>
  
  <aside class="info-sidebar">
    <!-- Sidebar -->
  </aside>
</main>
```

### Featured Article
```html
<article class="featured-article">
  <div class="article-content">
    <h3 class="article-title">Titolo</h3>
    <p class="article-date">Data</p>
    <p class="article-text">Testo</p>
  </div>
  <div class="article-image">
    <img src="..." class="featured-image">
  </div>
</article>
```

### Secondary News
```html
<div class="secondary-news">
  <article class="news-item">
    <h4 class="news-title">Titolo</h4>
    <p class="news-date">Data</p>
    <p class="news-summary">Riassunto</p>
  </article>
</div>
```

### Footer
```html
<footer class="site-footer">
  <div class="footer-content">
    <div class="footer-section">
      <h4>Titolo</h4>
      <address class="footer-address">
        <a href="mailto:...">Email</a>
      </address>
    </div>
  </div>
</footer>
```

---

## 🛠️ Utility Classes

### Margin Utilities
```html
<!-- Margin Bottom -->
<div class="mb-0">  <!-- margin-bottom: 0 -->
<div class="mb-sm"> <!-- margin-bottom: 0.5rem -->
<div class="mb-md"> <!-- margin-bottom: 1rem -->
<div class="mb-lg"> <!-- margin-bottom: 1.5rem -->
<div class="mb-xl"> <!-- margin-bottom: 2rem -->

<!-- Margin Top -->
<div class="mt-0">  <!-- margin-top: 0 -->
<div class="mt-sm"> <!-- margin-top: 0.5rem -->
<!-- etc... -->
```

### Text Utilities
```html
<div class="text-center">Testo centrato</div>
```

---

## 🎯 Come Personalizzare i Colori

### Opzione 1: Modificare le variabili (raccomandato)
```css
:root {
  --color-primary: #TUO_COLORE;
  --color-text: #TUO_COLORE;
}
```

### Opzione 2: Sovrascrivere in un CSS custom
```css
/* custom.css - carica DOPO stile_bricoccole.css */
:root {
  --color-primary: #new-color;
}
```

---

## ✨ Best Practices

### DO ✅
```html
<!-- Usa le classi semantiche -->
<article class="news-item">
  <h4 class="news-title">...</h4>
</article>

<!-- Usa variabili per spacing custom -->
<style>
  .my-custom-class {
    padding: var(--space-lg);
    color: var(--color-text);
  }
</style>
```

### DON'T ❌
```html
<!-- NON usare inline styles -->
<div style="margin: 20px;">...</div>

<!-- NON duplicare codice CSS -->
<style>
  .classe1 { padding: 1.5rem; }
  .classe2 { padding: 1.5rem; } /* usa --space-lg! */
</style>
```

---

## 🚀 Performance Tips

1. **Carica font localmente** (già fatto con Monotype Corsiva)
2. **Usa `font-display: swap`** per evitare FOIT
3. **Lazy load immagini** sotto il fold
4. **Minifica CSS in produzione**

---

## ♿ Accessibilità

### Già implementato:
- ✅ Focus visibile per keyboard navigation
- ✅ Contrasto colori WCAG AA compliant
- ✅ Supporto `prefers-reduced-motion`
- ✅ Supporto `prefers-contrast: high`
- ✅ Semantic HTML strutturato

### Come testare:
1. Naviga con TAB - verifica focus visibile
2. Usa screen reader (NVDA, JAWS)
3. Testa con 200% zoom nel browser
4. Verifica contrasti con tool online

---

## 🔧 Migrazione dal Vecchio CSS

### Passo 1: Backup
```bash
cp stile_bricoccole.css stile_bricoccole.OLD.css
```

### Passo 2: Sostituisci il CSS
```bash
cp stile_bricoccole_refactored.css stile_bricoccole.css
```

### Passo 3: Testa tutte le pagine
- `/index`
- `/login`
- `/news`
- Tutte le altre pagine

### Passo 4: Verifica responsive
- Apri DevTools (F12)
- Toggle device toolbar
- Testa mobile, tablet, desktop

---

## 📊 Confronto Versione Vecchia vs Nuova

| Aspetto | Vecchia | Nuova |
|---------|---------|-------|
| Righe di codice | ~550 | ~600 |
| Variabili CSS | ❌ | ✅ 40+ |
| Mobile-first | ❌ | ✅ |
| Accessibilità | Base | Completa |
| Utility classes | ❌ | ✅ |
| Manutenibilità | Media | Alta |
| Documentazione | Minima | Estesa |

---

## 🎓 Esempi Pratici

### Esempio 1: Aggiungere una nuova sezione
```html
<section class="content-section">
  <h2 class="section-title">Nuova Sezione</h2>
  <p>Il tuo contenuto qui...</p>
</section>
```

### Esempio 2: Creare una nuova card
```html
<div class="info-card">
  <h3 class="info-title">Titolo Card</h3>
  <p>Contenuto della card</p>
</div>
```

### Esempio 3: Form custom
```html
<form class="form-style">
  <input type="text" class="form-input" placeholder="Nome">
  <input type="email" class="form-input" placeholder="Email">
  <button type="submit" class="form-button">Invia</button>
</form>
```

---

## 🐛 Troubleshooting

### Problema: Font non carica
**Soluzione**: Verifica path in `fonts_bricoccole.css`
```css
src: url("../media/fonts/Monotype-Corsiva-Regular.ttf")
```

### Problema: Colori non cambiano
**Soluzione**: Svuota cache browser (Ctrl+Shift+R)

### Problema: Layout rotto su mobile
**Soluzione**: Verifica meta viewport in `<head>`
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

---

## 📚 Risorse Utili

- [CSS Variables - MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties)
- [CSS Grid - Complete Guide](https://css-tricks.com/snippets/css/complete-guide-grid/)
- [Accessibility Checklist](https://www.a11yproject.com/checklist/)
- [WCAG Contrast Checker](https://webaim.org/resources/contrastchecker/)

---

## 📝 Changelog

### v2.0 (2025-02-15)
- ✨ Introdotte CSS Variables
- ♻️ Refactoring completo della struttura
- 📱 Implementato approccio mobile-first
- ♿ Migliorata accessibilità
- 📚 Aggiunta documentazione completa
- 🎨 Sistemato spacing system
- 🚀 Ottimizzate performance

### v1.0 (Precedente)
- Versione iniziale

---

## 👥 Contribuire

Per migliorare questo CSS:
1. Testa su diversi dispositivi
2. Segnala bug o problemi
3. Proponi miglioramenti
4. Mantieni la documentazione aggiornata

---

## 📄 Licenza

Proprietario: BRICOCCOLE Allevamento
